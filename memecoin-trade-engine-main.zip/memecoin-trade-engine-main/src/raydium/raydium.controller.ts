import { Controller, Get, Post, Query } from '@nestjs/common';
import { RaydiumService } from './raydium.service';

@Controller('raydium')
export class RaydiumController {
  constructor(private readonly raydiumService: RaydiumService) {}

  @Post('swap')
  async swap() {
    console.log('calling swap endpoint');
    return await this.raydiumService.swap();
  }
}
