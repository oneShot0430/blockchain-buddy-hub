import {
  Connection,
  PublicKey,
  Keypair,
  Transaction,
  VersionedTransaction,
  TransactionMessage,
} from '@solana/web3.js';
import {
  Liquidity,
  LiquidityPoolKeys,
  jsonInfo2PoolKeys,
  LiquidityPoolJsonInfo,
  TokenAccount,
  Token,
  TokenAmount,
  TOKEN_PROGRAM_ID,
  Percent,
  SPL_ACCOUNT_LAYOUT,
  LIQUIDITY_STATE_LAYOUT_V4,
  MARKET_STATE_LAYOUT_V3,
  MAINNET_PROGRAM_ID,
} from '@raydium-io/raydium-sdk';
import { Wallet } from '@coral-xyz/anchor';
import * as bs58 from 'bs58';
import { readFileSync } from 'fs';
import { join } from 'path';
import { Injectable } from '@nestjs/common';

/**
 * Class representing a Raydium Swap operation.
 */
@Injectable()
export class RaydiumService {
  allPoolKeysJson: LiquidityPoolJsonInfo[];
  connection: Connection;
  wallet: Wallet;

  /**
   * Create a RaydiumSwap instance.
   * @param {string} RPC_URL - The RPC URL for connecting to the Solana blockchain.
   * @param {string} WALLET_PRIVATE_KEY - The private key of the wallet in base58 format.
   */
  constructor() {
    this.connection = new Connection('https://api.mainnet-beta.solana.com', {
      commitment: 'confirmed',
    });
    this.wallet = new Wallet(
      Keypair.fromSecretKey(
        Uint8Array.from(bs58.decode(process.env.SOLANA_PRIVATE_KEY)),
      ),
    );
  }

  /**
   * Loads all the pool keys available from a JSON configuration file.
   * @async
   * @returns {Promise<void>}
   */
  async loadPoolKeys(liquidityFile: string): Promise<void> {
    let liquidityJson;
    if (liquidityFile.startsWith('http')) {
      const liquidityJsonResp = await fetch(liquidityFile);
      if (!liquidityJsonResp.ok) return;
      liquidityJson = await liquidityJsonResp.json();
    } else {
      liquidityJson = JSON.parse(
        readFileSync(join(process.cwd(), liquidityFile), 'utf-8'),
      );
    }
    const allPoolKeysJson = [
      ...(liquidityJson?.official ?? []),
      ...(liquidityJson?.unOfficial ?? []),
    ];

    this.allPoolKeysJson = allPoolKeysJson;
  }

  /**
   * Finds pool information for the given token pair.
   * @param {string} mintA - The mint address of the first token.
   * @param {string} mintB - The mint address of the second token.
   * @returns {LiquidityPoolKeys | null} The liquidity pool keys if found, otherwise null.
   */
  findPoolInfoForTokens(
    mintA: string,
    mintB: string,
  ): LiquidityPoolKeys | null {
    if (!this.allPoolKeysJson) {
      return null;
    }

    const poolData = this.allPoolKeysJson.find(
      (i) =>
        (i.baseMint === mintA && i.quoteMint === mintB) ||
        (i.baseMint === mintB && i.quoteMint === mintA),
    );

    if (!poolData) return null;

    return jsonInfo2PoolKeys(poolData) as LiquidityPoolKeys;
  }

  /**
   * Finds pool information for the given pool ID.
   * @param {string} poolId - The AMM ID to query
   * @returns {LiquidityPoolKeys | null} The liquidity pool keys if found, otherwise null
   */
  async findPoolInfoByPoolId(
    poolId: string,
  ): Promise<LiquidityPoolKeys | null> {
    const poolKeys = await this.getPoolKeysByPoolId(poolId);
    if (!poolKeys) {
      return null;
    }

    // Convert pool keys to LiquidityPoolKeys format
    return {
      id: poolKeys.id,
      baseMint: poolKeys.baseMint,
      quoteMint: poolKeys.quoteMint,
      lpMint: poolKeys.lpMint,
      version: poolKeys.version,
      programId: poolKeys.programId,
      authority: poolKeys.authority,
      openOrders: poolKeys.openOrders,
      targetOrders: poolKeys.targetOrders,
      baseVault: poolKeys.baseVault,
      quoteVault: poolKeys.quoteVault,
      marketVersion: 3,
      marketProgramId: poolKeys.marketProgramId,
      marketId: poolKeys.marketId,
      marketAuthority: poolKeys.marketAuthority,
      marketBaseVault: poolKeys.marketBaseVault,
      marketQuoteVault: poolKeys.marketQuoteVault,
      marketBids: poolKeys.marketBids,
      marketAsks: poolKeys.marketAsks,
      marketEventQueue: poolKeys.marketEventQueue,
      lookupTableAccount: undefined,
    } as LiquidityPoolKeys;
  }

  /**
   * Retrieves token accounts owned by the wallet.
   * @async
   * @returns {Promise<TokenAccount[]>} An array of token accounts.
   */
  async getOwnerTokenAccounts(): Promise<TokenAccount[]> {
    const walletTokenAccount = await this.connection.getTokenAccountsByOwner(
      this.wallet.publicKey,
      {
        programId: TOKEN_PROGRAM_ID,
      },
    );

    return walletTokenAccount.value.map((i) => ({
      pubkey: i.pubkey,
      programId: i.account.owner,
      accountInfo: SPL_ACCOUNT_LAYOUT.decode(i.account.data),
    }));
  }

  /**
   * Builds a swap transaction.
   * @async
   * @param {string} toToken - The mint address of the token to receive.
   * @param {number} amount - The amount of the token to swap.
   * @param {LiquidityPoolKeys} poolKeys - The liquidity pool keys.
   * @param {number} [maxLamports=100000] - The maximum lamports to use for transaction fees.
   * @param {boolean} [useVersionedTransaction=true] - Whether to use a versioned transaction.
   * @param {'in' | 'out'} [fixedSide='in'] - The fixed side of the swap ('in' or 'out').
   * @returns {Promise<Transaction | VersionedTransaction>} The constructed swap transaction.
   */
  async getSwapTransaction(
    toToken: string,
    amount: number,
    poolKeys: LiquidityPoolKeys,
    maxLamports: number = 100000,
    useVersionedTransaction = true,
    fixedSide: 'in' | 'out' = 'in',
  ): Promise<Transaction | VersionedTransaction> {
    const directionIn = poolKeys.quoteMint.toString() == toToken;
    const { minAmountOut, amountIn } = await this.calcAmountOut(
      poolKeys,
      amount,
      directionIn,
    );
    console.log({ minAmountOut, amountIn });
    const userTokenAccounts = await this.getOwnerTokenAccounts();
    const swapTransaction = await Liquidity.makeSwapInstructionSimple({
      connection: this.connection as any,
      makeTxVersion: useVersionedTransaction ? 0 : 1,
      poolKeys: {
        ...poolKeys,
      },
      userKeys: {
        tokenAccounts: userTokenAccounts,
        owner: this.wallet.publicKey,
      },
      amountIn: amountIn,
      amountOut: minAmountOut,
      fixedSide: fixedSide,
      config: {
        bypassAssociatedCheck: false,
      },
      computeBudgetConfig: {
        microLamports: maxLamports,
      },
    });

    const recentBlockhashForSwap = await this.connection.getLatestBlockhash();
    const instructions =
      swapTransaction.innerTransactions[0].instructions.filter(Boolean);

    if (useVersionedTransaction) {
      const versionedTransaction = new VersionedTransaction(
        new TransactionMessage({
          payerKey: this.wallet.publicKey,
          recentBlockhash: recentBlockhashForSwap.blockhash,
          instructions: instructions,
        }).compileToV0Message(),
      );

      versionedTransaction.sign([this.wallet.payer]);

      return versionedTransaction;
    }

    const legacyTransaction = new Transaction({
      blockhash: recentBlockhashForSwap.blockhash,
      lastValidBlockHeight: recentBlockhashForSwap.lastValidBlockHeight,
      feePayer: this.wallet.publicKey,
    });

    legacyTransaction.add(...instructions);

    return legacyTransaction;
  }

  /**
   * Sends a legacy transaction.
   * @async
   * @param {Transaction} tx - The transaction to send.
   * @returns {Promise<string>} The transaction ID.
   */
  async sendLegacyTransaction(
    tx: Transaction,
    maxRetries?: number,
  ): Promise<string> {
    const txid = await this.connection.sendTransaction(
      tx,
      [this.wallet.payer],
      {
        skipPreflight: true,
        maxRetries: maxRetries,
      },
    );

    return txid;
  }

  /**
   * Sends a versioned transaction.
   * @async
   * @param {VersionedTransaction} tx - The versioned transaction to send.
   * @returns {Promise<string>} The transaction ID.
   */
  async sendVersionedTransaction(
    tx: VersionedTransaction,
    maxRetries?: number,
  ): Promise<string> {
    const txid = await this.connection.sendTransaction(tx, {
      skipPreflight: false,
      maxRetries: maxRetries,
    });

    return txid;
  }

  /**
   * Simulates a versioned transaction.
   * @async
   * @param {VersionedTransaction} tx - The versioned transaction to simulate.
   * @returns {Promise<any>} The simulation result.
   */
  async simulateLegacyTransaction(tx: Transaction): Promise<any> {
    const txid = await this.connection.simulateTransaction(tx, [
      this.wallet.payer,
    ]);

    return txid;
  }

  /**
   * Simulates a versioned transaction.
   * @async
   * @param {VersionedTransaction} tx - The versioned transaction to simulate.
   * @returns {Promise<any>} The simulation result.
   */
  async simulateVersionedTransaction(tx: VersionedTransaction): Promise<any> {
    const txid = await this.connection.simulateTransaction(tx, {
      sigVerify: true,
    });

    return txid;
  }

  /**
   * Gets a token account by owner and mint address.
   * @param {PublicKey} mint - The mint address of the token.
   * @returns {TokenAccount} The token account.
   */
  getTokenAccountByOwnerAndMint(mint: PublicKey): TokenAccount {
    return {
      programId: TOKEN_PROGRAM_ID,
      pubkey: PublicKey.default,
      accountInfo: {
        mint: mint,
        amount: 0,
      },
    } as unknown as TokenAccount;
  }

  /**
   * Calculates the amount out for a swap.
   * @async
   * @param {LiquidityPoolKeys} poolKeys - The liquidity pool keys.
   * @param {number} rawAmountIn - The raw amount of the input token.
   * @param {boolean} swapInDirection - The direction of the swap (true for in, false for out).
   * @returns {Promise<Object>} The swap calculation result.
   */
  async calcAmountOut(
    poolKeys: LiquidityPoolKeys,
    rawAmountIn: number,
    swapInDirection: boolean,
  ): Promise<any> {
    const poolInfo = await Liquidity.fetchInfo({
      connection: this.connection as any,
      poolKeys,
    });

    let currencyInMint = poolKeys.baseMint;
    let currencyInDecimals = poolInfo.baseDecimals;
    let currencyOutMint = poolKeys.quoteMint;
    let currencyOutDecimals = poolInfo.quoteDecimals;

    if (!swapInDirection) {
      currencyInMint = poolKeys.quoteMint;
      currencyInDecimals = poolInfo.quoteDecimals;
      currencyOutMint = poolKeys.baseMint;
      currencyOutDecimals = poolInfo.baseDecimals;
    }

    const currencyIn = new Token(
      TOKEN_PROGRAM_ID,
      currencyInMint,
      currencyInDecimals,
    );
    const amountIn = new TokenAmount(currencyIn, rawAmountIn, false);
    const currencyOut = new Token(
      TOKEN_PROGRAM_ID,
      currencyOutMint,
      currencyOutDecimals,
    );
    const slippage = new Percent(5, 100); // 5% slippage

    const {
      amountOut,
      minAmountOut,
      currentPrice,
      executionPrice,
      priceImpact,
      fee,
    } = Liquidity.computeAmountOut({
      poolKeys,
      poolInfo,
      amountIn,
      currencyOut,
      slippage,
    });

    return {
      amountIn,
      amountOut,
      minAmountOut,
      currentPrice,
      executionPrice,
      priceImpact,
      fee,
    };
  }

  /**
   * Gets pool keys by providing the pool's AMM ID
   * @async
   * @param {string} ammId - The AMM ID to query
   * @returns {Promise<any>} Pool keys and market information
   */
  async getPoolKeysByPoolId(ammId: string): Promise<any> {
    console.log(`Getting pool keys for ${ammId}`);

    const ammAccount = await this.connection.getAccountInfo(
      new PublicKey(ammId),
    );
    if (ammAccount) {
      const poolState = LIQUIDITY_STATE_LAYOUT_V4.decode(ammAccount.data);

      const marketAccount = await this.connection.getAccountInfo(
        poolState.marketId,
      );
      if (marketAccount) {
        const marketState = MARKET_STATE_LAYOUT_V3.decode(marketAccount.data);

        const marketAuthority = PublicKey.createProgramAddressSync(
          [
            marketState.ownAddress.toBuffer(),
            marketState.vaultSignerNonce.toArrayLike(Buffer, 'le', 8),
          ],
          MAINNET_PROGRAM_ID.OPENBOOK_MARKET,
        );

        return {
          id: new PublicKey(ammId),
          programId: MAINNET_PROGRAM_ID.AmmV4,
          status: poolState.status,
          baseDecimals: poolState.baseDecimal.toNumber(),
          quoteDecimals: poolState.quoteDecimal.toNumber(),
          lpDecimals: 9,
          baseMint: poolState.baseMint,
          quoteMint: poolState.quoteMint,
          version: 4,
          authority: new PublicKey(
            '5Q544fKrFoe6tsEbD7S8EmxGTJYAKtTVhAW5Q5pge4j1',
          ),
          openOrders: poolState.openOrders,
          baseVault: poolState.baseVault,
          quoteVault: poolState.quoteVault,
          marketProgramId: MAINNET_PROGRAM_ID.OPENBOOK_MARKET,
          marketId: marketState.ownAddress,
          marketBids: marketState.bids,
          marketAsks: marketState.asks,
          marketEventQueue: marketState.eventQueue,
          marketBaseVault: marketState.baseVault,
          marketQuoteVault: marketState.quoteVault,
          marketAuthority: marketAuthority,
          targetOrders: poolState.targetOrders,
          lpMint: poolState.lpMint,
        };
      }
    }
  }

  /**
   * Executes a swap transaction on Raydium.
   * @async
   * @param {SwapConfig} swapConfig - Configuration object containing swap parameters
   * @returns {Promise<string>} Transaction signature or simulation result
   */
  async swap(): Promise<string> {
    const swapConfig = {
      poolId: 'J4QwoP2Qj7kgQvBfN6vAzcGtJJXAwMNYgUah3K4VadD8',
      tokenAAddress: 'So11111111111111111111111111111111111111112',
      tokenBAddress: 'DxrupDm3nUtMtMRxfZVyUPgtunTKdgQjRmLTEv3Jpump',
      tokenAAmount: 0.0001,
      liquidityFile:
        'https://raw.githubusercontent.com/chainstacklabs/raydium-sdk-swap-example-typescript/refs/heads/main/src/trimmed_mainnet.json',
      maxLamports: 100000,
      useVersionedTransaction: true,
      direction: 'in' as any,
      maxRetries: 10,
      executeSwap: true,
      priorityFee: 1000000, // Add priority fee in microlamports
    };

    console.log(
      `Swapping ${swapConfig.tokenAAmount} of ${swapConfig.tokenAAddress} for ${swapConfig.tokenBAddress}...`,
    );

    const poolKeys = await this.getPoolKeysByPoolId(swapConfig.poolId);
    console.log(poolKeys);
    if (!poolKeys) {
      const error = 'Pool keys not found';
      console.error(error);
      return error;
    }

    // Find pool for token pair
    const poolInfo = await this.findPoolInfoByPoolId(swapConfig.poolId);
    if (!poolInfo) {
      const error = 'Pool info not found';
      console.error(error);
      return error;
    }
    console.log('Found pool info');

    // Build swap transaction
    const transaction = await this.getSwapTransaction(
      swapConfig.tokenBAddress,
      swapConfig.tokenAAmount,
      poolInfo,
      swapConfig.maxLamports,
      swapConfig.useVersionedTransaction,
      swapConfig.direction,
    );

    /**
     * Depending on the configuration, execute or simulate the swap.
     */
    if (swapConfig.executeSwap) {
      /**
       * Send the transaction to the network and log the transaction ID.
       */
      const txid = swapConfig.useVersionedTransaction
        ? await this.sendVersionedTransaction(
            transaction as VersionedTransaction,
            swapConfig.maxRetries,
          )
        : await this.sendLegacyTransaction(
            transaction as Transaction,
            swapConfig.maxRetries,
          );

      console.log(`https://solscan.io/tx/${txid}`);
    } else {
      /**
       * Simulate the transaction and log the result.
       */
      const simRes = swapConfig.useVersionedTransaction
        ? await this.simulateVersionedTransaction(
            transaction as VersionedTransaction,
          )
        : await this.simulateLegacyTransaction(transaction as Transaction);

      console.log(simRes);
    }
  }
}
