# Memecoin Trading Signal Monitor

A Python application that monitors memecoin trading pairs on Solana and sends trading signals via Telegram based on technical indicators.

## Features

- Real-time monitoring of multiple memecoin trading pairs
- Technical analysis using:
  - Moving Averages (9 & 21 period)
  - Bollinger Bands
  - RSI (Relative Strength Index)
  - MACD (Moving Average Convergence Divergence)
  - Volume Analysis
- Automated Telegram notifications when trading signals are detected
- Concurrent monitoring of multiple trading pairs using threading
- Error handling and automatic retries
- Configurable alert thresholds
- Historical data analysis
- Performance tracking and reporting
- Custom indicator combinations
- Risk management features

## Prerequisites

- Python 3.9+
- Poetry for dependency management
- Telegram Bot Token and Chat ID
- BirdEye API Key for Solana data
- At least 2GB RAM
- Stable internet connection

## Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/memecoin-analysis.git
   cd memecoin-analysis
   ```

2. Install Poetry if you haven't already:
   ```bash
   curl -sSL https://install.python-poetry.org | python3 -
   ```

3. Install dependencies using Poetry:
   ```bash
   poetry install
   ```

4. Create a `.env` file in the project root with your configuration:
   ```
   TELEGRAM_BOT_TOKEN=your_telegram_bot_token
   TELEGRAM_CHAT_ID=your_telegram_chat_id
   BIRDEYE_API_KEY=your_birdeye_api_key
   ```

5. Configure the monitored addresses in `memecoin_analysis/config.py` or add them to your `.env` file.

6. Run the application:
   ```bash
   poetry run python -m memecoin_analysis.main
   ```
