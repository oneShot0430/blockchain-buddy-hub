from threading import Thread
from memecoin_analysis.monitor.memecoin_monitor import MemecoinMonitor

class MemecoinMonitorManager:
    def __init__(self):
        self.monitors = []
        self.threads = []

    def add_monitor(self, address, bot_token, chat_id):
        monitor = MemecoinMonitor(address, bot_token, chat_id)
        self.monitors.append(monitor)
        thread = Thread(target=monitor.monitor)
        self.threads.append(thread)

    def start_all(self):
        for thread in self.threads:
            thread.start()

    def stop_all(self):
        for monitor in self.monitors:
            monitor.stop()
        for thread in self.threads:
            thread.join()