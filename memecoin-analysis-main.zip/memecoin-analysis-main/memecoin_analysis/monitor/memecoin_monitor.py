import requests
import time
import json
import pandas as pd
from memecoin_analysis.utils.indicators import calculate_indicators
from memecoin_analysis.config import Config

class MemecoinMonitor:
    def __init__(self, address, bot_token, chat_id):
        self.address = address
        self.bot_token = bot_token
        self.chat_id = chat_id
        self.running = True

    def get_ohlcv_data(self):
        # Calculate timestamps for last 1 hour to have enough data for indicators
        time_to = int(time.time())
        time_from = time_to - (2 * 60 * 60)  # 2 hours ago for calculating MAs

        url = f"https://public-api.birdeye.so/defi/ohlcv/pair?address={self.address}&type=5m&time_from={time_from}&time_to={time_to}"

        headers = {
            "accept": "application/json",
            "x-chain": "solana",
            "X-API-KEY": Config.BIRDEYE_API_KEY
        }

        response = requests.get(url, headers=headers)
        data = json.loads(response.text)
        
        # Convert to pandas DataFrame
        df = pd.DataFrame(data['data']['items'])
        
        # Convert numeric columns
        numeric_columns = ['c', 'h', 'l', 'o', 'v']
        for col in numeric_columns:
            df[col] = pd.to_numeric(df[col])
        
        # Rename columns to be more descriptive
        df = df.rename(columns={
            'c': 'close',
            'h': 'high',
            'l': 'low', 
            'o': 'open',
            'v': 'volume',
            'unixTime': 'timestamp'
        })
        
        return df

    def send_telegram_message(self, message):
        url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
        data = {
            "chat_id": self.chat_id,
            "text": message
        }
        requests.post(url, json=data)

    def check_signals(self, df):
        # Calculate indicators using the utility function
        df = calculate_indicators(df)
        
        # Get latest values
        current_ma9 = df['MA9'].iloc[-1]
        prev_ma9 = df['MA9'].iloc[-2]
        current_ma21 = df['MA21'].iloc[-1]
        prev_ma21 = df['MA21'].iloc[-2]
        current_low = df['low'].iloc[-1]
        current_bb_lower = df['BB_lower'].iloc[-1]
        current_rsi = df['RSI'].iloc[-1]
        
        # Check conditions
        ma_crossover = prev_ma9 < prev_ma21 and current_ma9 > current_ma21
        bb_touch = current_low <= current_bb_lower
        rsi_ok = current_rsi >= 30
        
        if ma_crossover and bb_touch and rsi_ok:
            message = (
                f"🚨 TRADE SIGNAL DETECTED for {self.address}! 🚨\n"
                f"📈 MA9: {current_ma9:.8f}\n"
                f"📉 MA21: {current_ma21:.8f}\n"
                f"💪 RSI: {current_rsi:.2f}\n"
                f"📊 Lower BB: {current_bb_lower:.8f}\n"
                "✨------------------------✨"
            )
            print(message)
            self.send_telegram_message(message)

    def monitor(self):
        print(f"🔍 Starting monitoring for address: {self.address}")
        address_short = self.address[:6] + "..." + self.address[-4:]  # Truncate long address for cleaner output
        
        while self.running:
            try:
                df = self.get_ohlcv_data()
                self.check_signals(df)
                # Use carriage return to update the same line for each address
                print(f"⏳ {address_short}: Checking signals... ")
                time.sleep(60)  # Wait for 1 minute before next check
            except Exception as e:
                error_message = f"❌ Error occurred for {address_short}: {str(e)}"
                print(error_message)
                print("🔄 Retrying in 60 seconds...")
                self.send_telegram_message(error_message)
                time.sleep(60)  # Wait before retrying

    def stop(self):
        self.running = False