import os
from dotenv import load_dotenv
from pathlib import Path

# Get the project root directory
ROOT_DIR = Path(__file__).parent.parent

# Load environment variables from .env file
load_dotenv(ROOT_DIR / '.env')

# Configuration class
class Config:
    TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
    TELEGRAM_CHAT_ID = os.getenv('TELEGRAM_CHAT_ID')
    BIRDEYE_API_KEY = os.getenv('BIRDEYE_API_KEY')

    MONITORED_ADDRESSES = [
        "3PqzL6n7ik1GJ2Y8vLm3Vs5yHGH4yDZd175gx7Ck4Sg1",
        "9wZvgFUqH2t9nYkPsTpBSUbHKgGH8Nb2koNQK5MhZJam",
        "9ZcnFX72eAvT2sKikHkZTuxaEYR5obcPbUDfyvfAWNpG",
        "JA8T6f95WftNWdcUJoFt1TQHqLKwU6TCK3inebcmuxMd",
        "4c6WsaZwuLfU1CsUL1SSmNYhp4M4QZF237UYCthZEoZZ",
    ]

    @classmethod
    def validate(cls):
        missing_vars = []
        for key, value in cls.__dict__.items():
            if not key.startswith('_') and value is None:
                missing_vars.append(key)
        
        if missing_vars:
            raise ValueError(f"Missing required environment variables: {', '.join(missing_vars)}")