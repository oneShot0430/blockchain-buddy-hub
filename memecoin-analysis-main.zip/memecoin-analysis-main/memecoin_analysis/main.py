import time
import requests
from memecoin_analysis.monitor.manager import MemecoinMonitorManager
from memecoin_analysis.config import Config

def send_telegram_message(bot_token, chat_id, message):
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    data = {
        "chat_id": chat_id,
        "text": message
    }
    requests.post(url, json=data)

def main():
    # Validate environment variables
    Config.validate()
    
    manager = MemecoinMonitorManager()
    
    # Get addresses from config
    addresses = Config.MONITORED_ADDRESSES
    if not addresses:
        raise ValueError("No addresses configured for monitoring")
    
    for address in addresses:
        manager.add_monitor(
            address=address,
            bot_token=Config.TELEGRAM_BOT_TOKEN,
            chat_id=Config.TELEGRAM_CHAT_ID
        )
    
    try:
        # Send startup message
        startup_message = "🚀 Memecoin Monitor Server Started! Signals will be sent here. 🚀\n\nMonitoring addresses:\n" + "\n".join(addresses)
        send_telegram_message(Config.TELEGRAM_BOT_TOKEN, Config.TELEGRAM_CHAT_ID, startup_message)
        
        manager.start_all()
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n🛑 Stopping all monitors...")
        manager.stop_all()

if __name__ == "__main__":
    main()